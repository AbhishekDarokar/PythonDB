import pymysql
con=pymysql.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
cur=con.cursor()
bi=int(input("enter bookcode: "))
bpz=int(input("enter book price: "))
cur.execute("select * from books where bookcode=%d"%bi)
result=cur.fetchone()
if result:
    cur.execute("update books set price=%d where bookcode=%d"%(bpz,bi))
    con.commit()
    print("price updated successfully")
else:
    print("Book Not Found")