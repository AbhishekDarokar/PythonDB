import pymysql as con
connection=con.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
curs=connection.cursor()
result=curs.execute("alter table books add reviews varchar(90)")
print(result)
if(result==0):
    print("column added successfully")
else:
    print("column not added")