import pymysql as con
connection=con.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
curs=connection.cursor()
curs.execute("select bookname from books")
result=curs.fetchall()
print("List of Books: ")
print()
for i in range(0,len(result)):
     print(i+1,"  ",result[i][0])

   
