import pymysql as con
connection=con.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
  
bn=input("Enter bookname: ")
bc=input("Enter book category: ")
ba=input("Enter book author: ")
bp=input("Enter book publication: ")
be=input("Enter book edition: ")
bpr=int(input("Enter book price: "))

curs=connection.cursor()

rs=curs.execute("insert into books(bookname,category,author,publication,edition,price) values('%s','%s','%s','%s','%s',%d)"%(bn,bc,ba,bp,be,bpr))
connection.commit()
if rs:
    print("Data Enter Sucessfully")
else:
    print("unable to enter")