import pymysql as con
connection=con.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
curs=connection.cursor()
au=input("enter author name: ")
pu=input("enter publication: ")
curs.execute("select author,publication from books where author='%s' and publication='%s'"%(au,pu))
result=curs.fetchall()
print("\nList of Books(author and publication): ")
if len(result)>0:
     for i in range(0,len(result)):
        print(i+1," ",result[i][0],"  ",result[i][1])
else:
    print("No record Found")