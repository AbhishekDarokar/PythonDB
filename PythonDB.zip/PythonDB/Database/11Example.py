import pymysql
con=pymysql.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
cur=con.cursor()
bi=int(input("Enter Bookcode: "))
rev=input("Write Review: ")
cur.execute("select * from books where bookcode=%d"%bi)
result=cur.fetchone()
if result:
    cur.execute("update books set review='%s' where bookcode=%d"%(rev,bi))
    con.commit()
    print("review updated successfully")
else:
    print("Book Not Found")