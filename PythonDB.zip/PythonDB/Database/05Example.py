import pymysql
con=pymysql.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
cur=con.cursor()
bi=int(input("enter bookcode: "))
cur.execute("select * from books where bookcode=%d"%bi)
result=cur.fetchone()
if result:
    print("\nbookname   :",result[1])
    print("category    :",result[2])
    print("author      :",result[3])
    print("publication :",result[4])
    print("edition     :",result[5])
    print("price       :",result[6])
else:
    print("Not Found")