import pymysql
con=pymysql.connect(host="localhost",port=3306,user="root",password="",database="bookstoredb")
cur=con.cursor()
bc=input("enter category: ")
bc.lower()
cur.execute("select * from books where category='%s'"%bc)
result=cur.fetchall()
print("\ntotal books:",len(result))
if result:
    for i in range(0,len(result)):
         print(i+1," ",result[i][1])   
else:
    print("  Not Found")