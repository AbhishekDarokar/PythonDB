def connectiondb:
     import pymysql as mycon
     con=mycon.connect(host='localhost',port=3306,user='root',password='',database='python_db')
     if con:
         print("connected")
     else:
         print("Not connected")
    